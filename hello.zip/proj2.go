package proj2

// You MUST NOT change what you import.  If you add ANY additional
// imports it will break the autograder, and we will be Very Upset.

import (
	// You neet to add with
	// userlib.go
	"github.com/cs161-staff/userlib"

	// Life is much easier with json:  You are
	// going to want to use this so you can easily
	// turn complex structures into strings etc...
	"encoding/json"

	// Likewise useful for debugging etc
	"encoding/hex"

	// UUIDs are generated right based on the crypto RNG
	// so lets make life easier and use those too...
	//
	// You need to add with "go get github.com/google/uuid"
	"github.com/google/uuid"

	// Useful for debug messages, or string manipulation for datastore keys
	"strings"

	// Want to import errors
	"errors"

	// optional
	_ "strconv"

	// if you are looking for fmt, we don't give you fmt, but you can use userlib.DebugMsg
	// see someUsefulThings() below
)

// This serves two purposes: It shows you some useful primitives and
// it suppresses warnings for items not being imported
func someUsefulThings() {
	// Creates a random UUID
	f := uuid.New()
	userlib.DebugMsg("UUID as string:%v", f.String())

	// Example of writing over a byte of f
	f[0] = 10
	userlib.DebugMsg("UUID as string:%v", f.String())

	// takes a sequence of bytes and renders as hex
	h := hex.EncodeToString([]byte("fubar"))
	userlib.DebugMsg("The hex: %v", h)

	// Marshals data into a JSON representation
	// Will actually work with go structures as well
	d, _ := json.Marshal(f)
	userlib.DebugMsg("The json data: %v", string(d))
	var g uuid.UUID
	json.Unmarshal(d, &g)
	userlib.DebugMsg("Unmashaled data %v", g.String())

	// This creates an error type
	userlib.DebugMsg("Creation of error %v", errors.New(strings.ToTitle("This is an error")))

	// And a random RSA key.  In this case, ignoring the error
	// return value
	var pk userlib.PKEEncKey
	var sk userlib.PKEDecKey
	pk, sk, _ = userlib.PKEKeyGen()
	userlib.DebugMsg("Key is %v, %v", pk, sk)
}

// Helper function: Takes the first 16 bytes and
// converts it into the UUID type
func bytesToUUID(data []byte) (ret uuid.UUID) {
	for x := range ret {
		ret[x] = data[x]
	}
	return
}

// The structure definition for a user record
type User struct {
	Username string
	Password string
	PK_PublicEncrypt userlib.PKEEncKey
	PK_PrivateDecrypt userlib.PKEDecKey
	DS_PrivateSign userlib.DSSignKey
	DS_PublicVerify userlib.DSVerifyKey
	FileStorage map[string]KeyStorage

	// You can add other fields here if you want...
	// Note for JSON to marshal/unmarshal, the fields need to
	// be public (start with a capital letter)
}

type KeyStorage struct {
	HMAC []byte
	ENC []byte
	FileDATAkey uuid.UUID
}

type File struct {
	Data []byte
}

type FileData struct {
	Length int
	sharedPeople map[string]int
}

type ShareAgreement struct {
	FileDATAkey uuid.UUID
	Signature []byte
	AgreementKey []byte
}

// This creates a user.  It will only be called once for a user
// (unless the keystore and datastore are cleared during testing purposes)

// It should store a copy of the userdata, suitably encrypted, in the
// datastore and should store the user's public key in the keystore.

// The datastore may corrupt or completely erase the stored
// information, but nobody outside should be able to get at the stored
// User data: the name used in the datastore should not be guessable
// without also knowing the password and username.

// You are not allowed to use any global storage other than the
// keystore and the datastore functions in the userlib library.

// You can assume the user has a STRONG password
func InitUser(username string, password string) (userdataptr *User, err error) {
	var userData User
	userdataptr = &userData

	//Generating PKE keys
	pkeEncKey, pkeDecKey, _ := userlib.PKEKeyGen()

	_ = userlib.KeystoreSet("pkeEncKey" + username, pkeEncKey)

	//Generating DS keys
	dsSignKey, dsVerifyKey, _ := userlib.DSKeyGen()

	_ = userlib.KeystoreSet("dsVerifyKey" + username, dsVerifyKey)

	//Making a new User struct
	userData = User{username,password, pkeEncKey,pkeDecKey,
		dsSignKey,dsVerifyKey,make(map[string]KeyStorage)}

	//Marshalling data into json representation
	jsonUser, _ := json.Marshal(userData)

	//Hashing the password with the hash of the username as the salt to make a key for the user
	usernameHash, _ := userlib.HMACEval(make([]byte, 16),[]byte(username))

	passwordHash := userlib.Argon2Key([]byte(password),usernameHash,16*2)

	//Encrypting the json representation of the User struct with a random salt, and then HMAC the encryption
	//First 16 bytes of the passwordHash is the key for userEnc; last 16 bytes is key for HMAC
	userDataEncKey := passwordHash[:16]
	userHMACKey := passwordHash[16:]

	userDataEnc := userlib.SymEnc(userDataEncKey, userlib.RandomBytes(16), jsonUser)
	userHMAC, _ := userlib.HMACEval(userHMACKey, userDataEnc)

	//Storing the encrypted user data into Datastore
	encUUID, _ := uuid.FromBytes(append([]byte("enc"), usernameHash[:13]...)[:16])
	userlib.DatastoreSet(encUUID, userDataEnc)

	//Storing the user HMAC into Datastore
	hmacUUID, _ := uuid.FromBytes(append([]byte("hmac"), usernameHash[:12]...)[:16])
	userlib.DatastoreSet(hmacUUID, userHMAC)

	return &userData, nil
}

// This fetches the user information from the Datastore.  It should
// fail with an error if the user/password is invalid, or if the user
// data was corrupted, or if the user can't be found.
func GetUser(username string, password string) (userdataptr *User, err error) {
	var userdata User
	userdataptr = &userdata

	//Get the hash of the username
	usernameHash, _ := userlib.HMACEval(make([]byte,16),[]byte(username))

	//Get the hash of the password in order to check the HMAC later
	passwordHash := userlib.Argon2Key([]byte(password),usernameHash,16*2)

	//retreiving the encrypted user data from the datastore
	encUUID, _ := uuid.FromBytes(append([]byte("enc"), usernameHash[:13]...)[:16])
	userEnc, result1 := userlib.DatastoreGet(encUUID)

	if result1 == false {
		return userdataptr, errors.New("failed DatastoreGet for result 1 ")
	}

	//retreiving the user HMAC from the datastore
	hmacUUID, _ := uuid.FromBytes(append([]byte("hmac"), usernameHash[:12]...)[:16])

	userHMAC, result2 := userlib.DatastoreGet(hmacUUID)
	if result2 == false {
		return userdataptr, errors.New("failed DatastoreGet for result 2 ")
	}

	//First 16 bytes of the passwordHash is the key for userEnc; last 16 bytes is key for HMAC
	userDataEncKey := passwordHash[:16]
	userHMACKey := passwordHash[16:]

	//finding the new HMAC
	newHMAC, _ := userlib.HMACEval(userHMACKey, userEnc)

	//Comparing the new HMAC with the original HMAC to see if anything changed
	if (userlib.HMACEqual(newHMAC, userHMAC) == false) {
		return userdataptr, errors.New("failed HMACEqual!")
	}

	//Decrypting user data and unmarshalling it into userdataptr
	userDataDecrypted := userlib.SymDec(userDataEncKey, userEnc)
	_ = json.Unmarshal(userDataDecrypted, userdataptr)

	return userdataptr, nil
}

// This stores a file in the datastore.
//
// The name and length of the file should NOT be revealed to the datastore!
func (userdata *User) StoreFile(filename string, data []byte) {

	//creating the FileData struct for the data
	newFileData := FileData{
		Length: 1,
		sharedPeople: make(map[string]int),
	}

	//this is the dataStore key for fileData
	//ENCkey and HMACkey for the fileData
	fileENCkey,fileHMACkey := userlib.RandomBytes(16), userlib.RandomBytes(16)
	fileDATAkey := uuid.New()

	tempVariable := []byte(fileDATAkey.String())
	tempVariable2 := []byte(fileDATAkey.String()+ string(1))

	//this is the dataStore key for file
	fileKeytemp := userlib.Argon2Key(tempVariable2, tempVariable, 16)

	fileKey,_ := uuid.FromBytes(fileKeytemp)
	newFile := File{data}

	//Adding to the KeyStorage
	userdata.FileStorage[filename] = KeyStorage{
		HMAC:        fileHMACkey,
		ENC:         fileENCkey,
		FileDATAkey: fileDATAkey,
	}

	//Marshall and then encrypted
	fileJSON, _ := json.Marshal(newFile)
	fileEnrypted := userlib.SymEnc(fileENCkey, userlib.RandomBytes(16),fileJSON)

	filedataJSON, _ := json.Marshal(newFileData)
	fileDATAEnrypted := userlib.SymEnc(fileENCkey, userlib.RandomBytes(16), filedataJSON)

	//make maps
	HMACfileMAP := make(map[int] []byte)
	HMACfiledataMAP := make(map[int] []byte)

	//Get HMAC
	fileHMACtemp, _  := userlib.HMACEval(fileHMACkey,fileEnrypted)
	HMACfileMAP[0] = fileEnrypted
	HMACfileMAP[1] = fileHMACtemp
	HMACfileMAPjson ,_ := json.Marshal(HMACfileMAP)
	userlib.DatastoreSet(fileKey, HMACfileMAPjson)

	dataHMACtemp, _  := userlib.HMACEval(fileHMACkey,fileDATAEnrypted)
	HMACfiledataMAP[0] = fileDATAEnrypted
	HMACfiledataMAP[1] = dataHMACtemp
	HMACfiledataMAPjson ,_ := json.Marshal(HMACfiledataMAP)
	userlib.DatastoreSet(fileDATAkey, HMACfiledataMAPjson)

	//Update dataStore with the changed user struct

	//Hashing the password with the hash of the username as the salt to make a key for the user
	usernameHash, _ := userlib.HMACEval(make([]byte,16),[]byte(userdata.Username))
	passwordHash := userlib.Argon2Key([]byte(userdata.Password), usernameHash,32)
	jsonUser, _ := json.Marshal(userdata)

	//Encrypting the json representation of the User struct with a random salt, and then HMAC the encryption
	//First 16 bytes of the passwordHash is the key for userEnc; last 16 bytes is key for HMAC
	userDataEnc := userlib.SymEnc(passwordHash[:16], userlib.RandomBytes(16), jsonUser)
	userHMAC, _ := userlib.HMACEval(passwordHash[16:], userDataEnc)

	//Storing the encrypted user data into Datastore
	encUUID, _ := uuid.FromBytes(append([]byte("enc"), usernameHash[:13]...)[:16])
	userlib.DatastoreSet(encUUID, userDataEnc)

	//Storing the user HMAC into Datastore
	hmacUUID, _ := uuid.FromBytes(append([]byte("hmac"), usernameHash[:12]...)[:16])
	userlib.DatastoreSet(hmacUUID, userHMAC)
}

// This loads a file from the Datastore.
//
// It should give an error if the file is corrupted in any way.
func (userdata *User) LoadFile(filename string) (data []byte, err error) {
	userKeys := userdata.FileStorage[filename]

	var fileData FileData
	var finalFile []byte
	var HMACfiledataMAPjson map[int] []byte

	//Retrieve the file data
	encryptedFileData, error := userlib.DatastoreGet(userKeys.FileDATAkey)

	if error == false {
		return finalFile, errors.New("No encryptedFileData in datastore")
	}
	_ = json.Unmarshal(encryptedFileData, &HMACfiledataMAPjson )

	//Calculate the HMAC
	fileDATAencrypted := HMACfiledataMAPjson[0]

	actualHMAC := HMACfiledataMAPjson[1]

	calculatedHMAC,_ := userlib.HMACEval(userKeys.HMAC, fileDATAencrypted)

	if userlib.HMACEqual(actualHMAC, calculatedHMAC) == false {
		return finalFile, errors.New("file data HMAC isn't equal! [load file pre for loop]")
	}
	tempBytes := userlib.SymDec(userKeys.ENC, fileDATAencrypted)
	_ = json.Unmarshal(tempBytes, &fileData)

	for counter := 1; counter <= fileData.Length; counter++ {
		var newFile File
		tempVariable := []byte(userKeys.FileDATAkey.String())
		tempVariable2 := []byte(userKeys.FileDATAkey.String() + string(counter))

		fileKeytemp := userlib.Argon2Key(tempVariable2, tempVariable, 16)
		fileKey,_ := uuid.FromBytes(fileKeytemp)

		fileEncrypted, error := userlib.DatastoreGet(fileKey)
		if error == false {
			return finalFile, errors.New("No fileEncrypted in datastore [Load File]")
		}

		var HMACfileMAPjson map[int] []byte
		_ = json.Unmarshal(fileEncrypted, &HMACfileMAPjson)

		fileENCshortened := HMACfileMAPjson[0]
		fileActualHMAC := HMACfileMAPjson[1]
		fileCalculatedHMAC,_ := userlib.HMACEval(userKeys.HMAC, fileENCshortened)

		if userlib.HMACEqual(fileActualHMAC, fileCalculatedHMAC) == false {
			return finalFile, errors.New("file HMAC isn't equal! [Load File]")
		}

		tempBytes2 := userlib.SymDec(userKeys.ENC, fileENCshortened)
		_ = json.Unmarshal(tempBytes2, &newFile)
		finalFile = append(finalFile, newFile.Data...)
	}
	return finalFile, nil
}


// This adds on to an existing file.
//
// Append should be efficient, you shouldn't rewrite or reencrypt the
// existing file, but only whatever additional information and
// metadata you need.
//
func (userdata *User) AppendFile(filename string, data []byte) (err error) {
	//Get the file data

	encryptedFileData, error := userlib.DatastoreGet(userdata.FileStorage[filename].FileDATAkey)
	if error == false {
		return errors.New("No encryptedFileData in datastore [for AppendFile]")
	}

	var HMACfiledataMAPjson2 map[int] []byte

	var fileData FileData

	_ = json.Unmarshal(encryptedFileData, &HMACfiledataMAPjson2)

	//Calculate the HMAC
	fileDATAencrypted := HMACfiledataMAPjson2[0]
	actualHMAC := HMACfiledataMAPjson2[1]

	calculatedHMAC,_ := userlib.HMACEval(userdata.FileStorage[filename].HMAC, fileDATAencrypted)

	if userlib.HMACEqual(actualHMAC, calculatedHMAC) == false {
		return errors.New("file data HMAC isn't equal! [for AppendFile]")
	}

	tempBytes := userlib.SymDec(userdata.FileStorage[filename].ENC, fileDATAencrypted)
	_ = json.Unmarshal(tempBytes, &fileData)

	newFile := File{data}

	//Create new file struct
	//this is the dataStore key for file
	tempVariable := []byte(userdata.FileStorage[filename].FileDATAkey.String() + string(fileData.Length + 1))
	tempVariable2 := []byte(userdata.FileStorage[filename].FileDATAkey.String())

	fileKeytemp := userlib.Argon2Key(tempVariable, tempVariable2, 16)
	fileKey,_ := uuid.FromBytes(fileKeytemp)

	//Marshall and then encrypted
	fileJSON, _ := json.Marshal(newFile)
	fileEnrypted := userlib.SymEnc(userdata.FileStorage[filename].ENC, userlib.RandomBytes(16), fileJSON)

	//make maps
	HMACfileMAP := make(map[int] []byte)
	HMACfiledataMAP := make(map[int] []byte)

	//Get HMAC
	fileHMACtemp, _  := userlib.HMACEval(userdata.FileStorage[filename].HMAC, fileEnrypted)

	HMACfileMAP[0] = fileEnrypted
	HMACfileMAP[1] = fileHMACtemp
	HMACfileMAPjson ,_ := json.Marshal(HMACfileMAP)

	//add to file length
	fileData.Length = fileData.Length + 1

	userlib.DatastoreSet(fileKey, HMACfileMAPjson)

	//encrypt the new file data and put back into dataStore
	fileDataJSON, _ := json.Marshal(fileData)

	fileDATAEnrypted := userlib.SymEnc(userdata.FileStorage[filename].ENC, userlib.RandomBytes(16), fileDataJSON)

	dataHMACtemp, _  := userlib.HMACEval(userdata.FileStorage[filename].HMAC,fileDATAEnrypted)
	HMACfiledataMAP[0] = fileDATAEnrypted
	HMACfiledataMAP[1] = dataHMACtemp

	HMACfiledataMAPjson ,_ := json.Marshal(HMACfiledataMAP)

	userlib.DatastoreSet(userdata.FileStorage[filename].FileDATAkey, HMACfiledataMAPjson)

	return nil
}

func (userdata *User) ShareFile(filename string, recipient string) (magic_string string, err error) {

	filekeysMAP := make(map[int] []byte)

	magicString := uuid.New().String()

	//Get the public key from KeyStore
	recipientPK, error := userlib.KeystoreGet("pkeEncKey" + recipient)
	if error == false {
		return magicString, errors.New("in ShareFile, recipient doesn't exist")
	}

	//Get the file's keys
	//appending the encryption and hmac keys together
	if _, ok := userdata.FileStorage[filename]; ok==false {
		return magicString, errors.New("doesn't exist")
	}

	filekeysMAP[0] = userdata.FileStorage[filename].ENC
	filekeysMAP[1] = userdata.FileStorage[filename].HMAC

	//Public key encryption of the fileKeysHMAC
	fileKeysHMACjson, _ := json.Marshal(filekeysMAP)

	fileKeysENC, _ := userlib.PKEEnc(recipientPK, fileKeysHMACjson)

	fileDSignatureKey, DSSign_error := userlib.DSSign(userdata.DS_PrivateSign,fileKeysENC)
	if DSSign_error != nil {
		return magic_string, errors.New("DSSign_error [for ShareFile]")
	}

	//Retrieve the file data
	var HMACfiledataMAPjson map[int] []byte
	var fileData FileData

	encryptedFileData, error := userlib.DatastoreGet(userdata.FileStorage[filename].FileDATAkey)
	_ = json.Unmarshal(encryptedFileData, &HMACfiledataMAPjson)
	fileDATAencrypted := HMACfiledataMAPjson[0]
	tempBytes := userlib.SymDec(userdata.FileStorage[filename].ENC, fileDATAencrypted)
	_ = json.Unmarshal(tempBytes, &fileData)
	mapGuy := make(map[string] int)

	for k, v := range fileData.sharedPeople {
		mapGuy[k] = v
	}
	mapGuy[recipient] = 1
	fileData.sharedPeople = mapGuy

	//for k, v := range fileData.sharedPeople {
	//	userlib.DebugMsg("Key is %v, %v", k,v)
	//}


	fileJSON, _ := json.Marshal(fileData)
	fileEnrypted := userlib.SymEnc(userdata.FileStorage[filename].ENC, userlib.RandomBytes(16), fileJSON)

	//make maps
	HMACfiledataMAP2 := make(map[int] []byte)

	//Get HMAC
	fileHMACtemp, _  := userlib.HMACEval(userdata.FileStorage[filename].HMAC, fileEnrypted)

	HMACfiledataMAP2[0] = fileEnrypted
	HMACfiledataMAP2[1] = fileHMACtemp
	HMACfileMAPjson2 ,_ := json.Marshal(HMACfiledataMAP2)

	userlib.DatastoreSet(userdata.FileStorage[filename].FileDATAkey, HMACfileMAPjson2)


	shareAgreementGuy := ShareAgreement{
		FileDATAkey:  userdata.FileStorage[filename].FileDATAkey,
		Signature:    fileDSignatureKey,
		AgreementKey: fileKeysENC,
	}

	//Update dataStore with the changed user struct

	//Hashing the password with the hash of the username as the salt to make a key for the user
	usernameHash, _ := userlib.HMACEval(make([]byte,16),[]byte(userdata.Username))
	passwordHash := userlib.Argon2Key([]byte(userdata.Password), usernameHash,32)
	jsonUser, _ := json.Marshal(userdata)

	//Encrypting the json representation of the User struct with a random salt, and then HMAC the encryption
	//First 16 bytes of the passwordHash is the key for userEnc; last 16 bytes is key for HMAC
	userDataEnc := userlib.SymEnc(passwordHash[:16], userlib.RandomBytes(16), jsonUser)
	userHMAC, _ := userlib.HMACEval(passwordHash[16:], userDataEnc)

	//Storing the encrypted user data into Datastore
	encUUID, _ := uuid.FromBytes(append([]byte("enc"), usernameHash[:13]...)[:16])
	userlib.DatastoreSet(encUUID, userDataEnc)

	//Storing the user HMAC into Datastore
	hmacUUID, _ := uuid.FromBytes(append([]byte("hmac"), usernameHash[:12]...)[:16])
	userlib.DatastoreSet(hmacUUID, userHMAC)

	magicUUID, _ := uuid.FromBytes([]byte(magic_string))

	shareAgreementGuyJSON,_ := json.Marshal(shareAgreementGuy)
	userlib.DatastoreSet(magicUUID, shareAgreementGuyJSON)

	return magicString, nil
}

// Note recipient's filename can be different from the sender's filename.
// The recipient should not be able to discover the sender's view on
// what the filename even is!  However, the recipient must ensure that
// it is authentically from the sender.
func (userdata *User) ReceiveFile(filename string, sender string, magic_string string) error {
	//Get the public key from KeyStore
	var ShareAgreement ShareAgreement
	var filekeysMAP map[int] []byte

	//Get the shareAgreement
	magicUUID, _ := uuid.FromBytes([]byte(magic_string))
	shareAgreementJSONencrypted, error := userlib.DatastoreGet(magicUUID)
	if error == false {
		return errors.New("in ReceiveFile, this magic_string doesn't exist")
	}

	//Unmarshalling the shareAgreement
	_ = json.Unmarshal(shareAgreementJSONencrypted, &ShareAgreement)

	senderPK, error := userlib.KeystoreGet("dsVerifyKey" + sender)
	if error == false {
		return errors.New("in ReceiveFIle, recipient doesn't exist")
	}

	//verifying the shareAgreement
	verifyDS_error := userlib.DSVerify(senderPK, ShareAgreement.AgreementKey, ShareAgreement.Signature)

	if verifyDS_error != nil {
		return errors.New("verifyDS_error [for ReceieveFile]")
	}

	//decrypting the shareAgreement
	shareAgreementJSONdecrypted, PKEDec_error := userlib.PKEDec(userdata.PK_PrivateDecrypt, ShareAgreement.AgreementKey)

	if PKEDec_error != nil {
		return errors.New("PKEDec_error [for ReceieveFile]")
	}
	//Unmarshalling the shareAgreement HMAC
	_ = json.Unmarshal(shareAgreementJSONdecrypted, &filekeysMAP)

	//Getting the fileKeys.Enc and fileKeys.HMAC keys
	encKey := filekeysMAP[0]
	hmacKey := filekeysMAP[1]

	//creating a new FileStorage with this shared file
	userdata.FileStorage[filename] = KeyStorage{
		HMAC:        hmacKey,
		ENC:         encKey,
		FileDATAkey: ShareAgreement.FileDATAkey,
	}

	//Updating Userdata [this part is different]
	//Update dataStore with the changed user struct

	//Hashing the password with the hash of the username as the salt to make a key for the user
	usernameHash, _ := userlib.HMACEval(make([]byte,16),[]byte(userdata.Username))
	passwordHash := userlib.Argon2Key([]byte(userdata.Password), usernameHash,32)
	jsonUser, _ := json.Marshal(userdata)

	//Encrypting the json representation of the User struct with a random salt, and then HMAC the encryption
	//First 16 bytes of the passwordHash is the key for userEnc; last 16 bytes is key for HMAC
	userDataEnc := userlib.SymEnc(passwordHash[:16], userlib.RandomBytes(16), jsonUser)
	userHMAC, _ := userlib.HMACEval(passwordHash[16:], userDataEnc)

	//Storing the encrypted user data into Datastore
	encUUID, _ := uuid.FromBytes(append([]byte("enc"), usernameHash[:13]...)[:16])
	userlib.DatastoreSet(encUUID, userDataEnc)

	//Storing the user HMAC into Datastore
	hmacUUID, _ := uuid.FromBytes(append([]byte("hmac"), usernameHash[:12]...)[:16])
	userlib.DatastoreSet(hmacUUID, userHMAC)

	return nil
}

// Removes target user's access.
func (userdata *User) RevokeFile(filename string, target_username string) (err error) {
	//Get the file's keys
	//appending the encryption and hmac keys together
	if _, ok := userdata.FileStorage[filename]; ok==false {
		return errors.New("doesn't exist")
	}

	var fileData FileData
	var HMACfiledataMAPjson map[int] []byte

	//Get the file data keys

	//get the file encrypted json file data
	tempBytes, error := userlib.DatastoreGet(userdata.FileStorage[filename].FileDATAkey)
	if error == false {
		return errors.New("No encryptedFileData in datastore [for RevokeFile]")
	}
	_ = json.Unmarshal(tempBytes, &HMACfiledataMAPjson)

	//Calculate the HMAC
	fileDATAencrypted := HMACfiledataMAPjson[0]
	actualHMAC := HMACfiledataMAPjson[1]
	calculatedHMAC,_ := userlib.HMACEval(userdata.FileStorage[filename].HMAC, fileDATAencrypted)

	//check if the hmac is the same
	if userlib.HMACEqual(actualHMAC, calculatedHMAC) == false {
		return errors.New("file data HMAC isn't equal! [for AppendFile]")
	}

	//Get new enc and hmac keys
	fileENCkey2 := userlib.Argon2Key(userlib.RandomBytes(16), userlib.RandomBytes(16),16)

	fileHMACkey2 := userlib.Argon2Key(userlib.RandomBytes(16), userlib.RandomBytes(16),16)


	//decrypt the json
	fileDATAJSONdecrypted := userlib.SymDec(userdata.FileStorage[filename].ENC, fileDATAencrypted)

	//json guy
	_ = json.Unmarshal(fileDATAJSONdecrypted, &fileData)

	mapGuy := make(map[string] int)

	for k, v := range fileData.sharedPeople {
		userlib.DebugMsg("Key 32232is %v, %v", k,v)
	}

	for k, v := range fileData.sharedPeople {
		mapGuy[k] = v
	}

	//
	//if _, ok := mapGuy[target_username]; ok==false {
	//	return errors.New("username doesn't exist")
	//}
	mapGuy[target_username] = 0
	fileData.sharedPeople = mapGuy

	//Encoding with a new key
	fileDATAjsonENC := userlib.SymEnc(fileENCkey2, userlib.RandomBytes(16), fileDATAJSONdecrypted)

	//getting the new HMAC with new hmac key
	HMACfileMAP := make(map[int] []byte)

	dataHMACtemp, _  := userlib.HMACEval(fileHMACkey2,fileDATAjsonENC)
	HMACfileMAP[0] = fileDATAjsonENC
	HMACfileMAP[1] = dataHMACtemp

	jsonMAP, _ := json.Marshal(HMACfileMAP)

	//Storing filedata and file into DataStore
	userlib.DatastoreSet(userdata.FileStorage[filename].FileDATAkey, jsonMAP)

	// going through every iteration of the file and decrypting, encrypting, and storing each key
	for counter := 1; counter <= fileData.Length; counter++ {
		tempVariable := []byte(userdata.FileStorage[filename].FileDATAkey.String() + string(counter))
		tempVariable2 := []byte(userdata.FileStorage[filename].FileDATAkey.String())
		fileKeytemp := userlib.Argon2Key(tempVariable, tempVariable2, 16)

		fileKey,_ := uuid.FromBytes(fileKeytemp)
		fileEncrypted, error := userlib.DatastoreGet(fileKey)
		if error == false {
			return errors.New("No fileEncrypted in datastore [Revoke File]")
		}

		var HMACfileMAPjson map[int] []byte
		_ = json.Unmarshal(fileEncrypted, &HMACfileMAPjson)

		fileENCshortened := HMACfileMAPjson[0]
		fileActualHMAC := HMACfileMAPjson[1]

		fileCalculatedHMAC,_ := userlib.HMACEval(userdata.FileStorage[filename].HMAC, fileENCshortened)

		if userlib.HMACEqual(fileActualHMAC, fileCalculatedHMAC) == false {
			return errors.New("file HMAC isn't equal! [Revoke File]")
		}

		//old decryption
		tempBytes2 := userlib.SymDec(userdata.FileStorage[filename].ENC, fileENCshortened)

		//new encryption
		newENCfile := userlib.SymEnc(fileENCkey2, userlib.RandomBytes(16), tempBytes2)

		//getting the HMAC
		HMACfileMAP2 := make(map[int] []byte)
		dataHMACtemp, _  := userlib.HMACEval(fileHMACkey2,newENCfile)
		HMACfileMAP2[0] = newENCfile
		HMACfileMAP2[1] = dataHMACtemp

		jsonMAP2, _ := json.Marshal(HMACfileMAP2)

		//storing the new hmac into the datastore
		userlib.DatastoreSet(fileKey, jsonMAP2)
	}

	userdata.FileStorage[filename] = KeyStorage{
		HMAC:        fileHMACkey2,
		ENC:         fileENCkey2,
		FileDATAkey: userdata.FileStorage[filename].FileDATAkey,
	}


	for k, v := range fileData.sharedPeople {
		if v == 1 {
			userdata.ShareFile(filename, k)
		}
	}

	//Updating Userdata [this part is different]
	//Update dataStore with the changed user struct

	//Hashing the password with the hash of the username as the salt to make a key for the user
	usernameHash, _ := userlib.HMACEval(make([]byte,16),[]byte(userdata.Username))
	passwordHash := userlib.Argon2Key([]byte(userdata.Password), usernameHash,32)
	jsonUser, _ := json.Marshal(userdata)

	//Encrypting the json representation of the User struct with a random salt, and then HMAC the encryption
	//First 16 bytes of the passwordHash is the key for userEnc; last 16 bytes is key for HMAC
	userDataEnc := userlib.SymEnc(passwordHash[:16], userlib.RandomBytes(16), jsonUser)
	userHMAC, _ := userlib.HMACEval(passwordHash[16:], userDataEnc)

	//Storing the encrypted user data into Datastore
	encUUID, _ := uuid.FromBytes(append([]byte("enc"), usernameHash[:13]...)[:16])
	userlib.DatastoreSet(encUUID, userDataEnc)

	//Storing the user HMAC into Datastore
	hmacUUID, _ := uuid.FromBytes(append([]byte("hmac"), usernameHash[:12]...)[:16])
	userlib.DatastoreSet(hmacUUID, userHMAC)

	return nil
}