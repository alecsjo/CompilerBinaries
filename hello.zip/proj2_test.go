package proj2

// You MUST NOT change what you import.  If you add ANY additional
// imports it will break the autograder, and we will be Very Upset.

import (
	_ "encoding/hex"
	_ "encoding/json"
	_ "encoding/json"
	_ "errors"
	"github.com/cs161-staff/userlib"
	_ "github.com/google/uuid"
	"reflect"
	_ "strconv"
	_ "strings"
	"testing"
)


func TestInit(t *testing.T) {
	t.Log("Initialization test")

	// You may want to turn it off someday
	//userlib.SetDebugStatus(true)
	//someUsefulThings()  //  Don't call someUsefulThings() in the autograder in case a student removes it
	//userlib.SetDebugStatus(false)

	_, err := InitUser("alice", "fubar")
	if err != nil {
		// t.Error says the test fails
		t.Error("Failed to initialize user", err)
		return
	}

	// t.Log() only produces output if you run with "go test -v"
	//t.Log("Got user", user1)
	// If you want to comment the line above,
	// write _ = u here to make the compiler happy
	// You probably want many more tests here.

	_, err = InitUser("Alec", "Jo")
	if err != nil {
		// t.Error says the test fails
		t.Error("Failed to initialize user", err)
		return
	}
	//t.Log("Got user", user2)

	_, err = InitUser("Lloyd", "Ashton")
	if err != nil {
		// t.Error says the test fails
		t.Error("Failed to initialize user", err)
		return
	}

	//no user
	_, err3 := GetUser("nobodyishome", "hihihi")
	if err3 == nil {
		t.Error("should've failed", err3)
		return
	}

	//wrong password
	_, err4 := GetUser("alice", "sdsdsd")
	if err3 == nil {
		t.Error("should've failed", err4)
		return
	}
	//getting the same person twice
	_, err5 := GetUser("alice", "fubar")
	if err5 != nil {
		t.Error("should've failed", err5)
		return
	}
	_, err6 := GetUser("alice", "fubar")
	if err6 != nil {
		t.Error("should've failed", err6)
		return
	}
}


func TestStorage(t *testing.T) {
	//And some more tests, because
	user1, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}

	v := []byte("This is a test")
	var hihihi []byte

	user1.StoreFile("file1", v)
	//try to store file that is empty
	user1.StoreFile("hihihihihihihi", hihihi)

	v2, err2 := user1.LoadFile("file1")
	if err2 != nil {
		t.Error("Failed to upload and download", err2)
		return
	}
	if !reflect.DeepEqual(v, v2) {
		t.Error("Downloaded file is not the same", v, v2)
		return
	}

	//loading something that's empty
	v4, err4 := user1.LoadFile("hihihihihihihi")
	if err4 != nil {
		t.Error("Failed to upload and download", err4)
		return
	}
	if !reflect.DeepEqual(hihihi, v4) {
		t.Error("Downloaded file is not the same", v, v2)
		return
	}

	//load file that doesn't exist
	_, err3 := user1.LoadFile("asbivrwbiuevuierv")
	if err3 == nil {
		t.Error("Should fail this guy", err3)
		return
	}

	//test if user structure updates after upload

	user69, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}

	if !reflect.DeepEqual(user69, user1) {
		t.Error("Should be the same", user69, user1)
		return
	}


	user2, err := GetUser("Alec", "Jo")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}
	//storing the same name and same file
	user2.StoreFile("file1", v)

	t.Log("Loaded user", user2)

	initialFile := []byte("Imagine breaking world records from the comfort of your home. " +
		"Never had a chance to showcase your special skills and talents? " +
		"Now, you can with aSend! aSend is a crowdsourced record compiler " +
		"powered by Blockchain that allows users to upload videos in various " +
		"activities and see how you rank against other people. It allows you " +
		"to unofficially join the prestigious Guinness World Record holders, " +
		"and provides accessibility for anyone to “aSend” the ranks.+Imagine breaking world records from the comfort of your home. " +
		"Never had a chance to showcase your special skills and talents? " +
		"Now, you can with aSend! aSend is a crowdsourced record compiler " +
		"powered by Blockchain that allows users to upload videos in various " +
		"activities and see how you rank against other people. It allows you " +
		"to unofficially join the prestigious Guinness World Record holders, " +
		"and provides accessibility for anyone to “aSend” the ranks.+Imagine breaking world records from the comfort of your home. " +
		"Never had a chance to showcase your special skills and talents? " )
	user2.StoreFile("file1", initialFile)

	user2.StoreFile("aSend", initialFile)

	loadedFile, err2 := user2.LoadFile("aSend")

	if err2 != nil {
		t.Error("Failed to upload and download", err2)
		return
	}
	if !reflect.DeepEqual(initialFile, loadedFile) {
		t.Error("Downloaded file is not the same", initialFile, loadedFile)
		return
	}

}

func TestAppend(t *testing.T) {
	// And some more tests, because
	u, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}
	t.Log("Loaded user", u)

	initialFile := []byte("Imagine breaking world records from the comfort of your home. " +
		"Never had a chance to showcase your special skills and talents? " +
		"Now, you can with aSend! aSend is a crowdsourced record compiler " +
		"powered by Blockchain that allows users to upload videos in various " +
		"activities and see how you rank against other people. It allows you " +
		"to unofficially join the prestigious Guinness World Record holders, " +
		"and provides accessibility for anyone to “aSend” the ranks.")
	appendFile := []byte("hello world")
	appendFile2 := []byte("John Moon SKillman")

	u.StoreFile("appendTest", initialFile)
	// append to someting that doesn't exist
	error6969 := u.AppendFile("ewoiewfdnowenofoniewf", initialFile)
	if error6969 == nil {
		t.Error("shoudl fail", error6969)
		return
	}
	loadedFile2, err2 := u.LoadFile("appendTest")
	if err2 != nil {
		t.Error("Failed to upload and download", err2)
		return
	}

	if !reflect.DeepEqual(initialFile, loadedFile2) {
		t.Error("Downloaded file is not the same", initialFile, loadedFile2)
		return
	}

	u.AppendFile("appendTest", appendFile)
	u.AppendFile("appendTest", appendFile2)


	loadedFile, err2 := u.LoadFile("appendTest")
	if err2 != nil {
		t.Error("Failed to upload and download", err2)
		return
	}

	initialFile = append(initialFile, appendFile...)
	initialFile = append(initialFile, appendFile2...)


	if !reflect.DeepEqual(initialFile, loadedFile) {
		t.Error("Downloaded file is not the same", initialFile, loadedFile)
		return
	}
}


func TestShare(t *testing.T) {
	u, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}
	u2, err2 := InitUser("bob", "foobar")
	if err2 != nil {
		t.Error("Failed to initialize bob", err2)
		return
	}

	var loadedBeforeAppend, initialFile []byte
	var magic_string string
	// share with someone that doesn't exist
	_, err23232 := u.ShareFile("file1", "dsiubsdubisdibu")
	if err23232 == nil {
		t.Error("should fail", err23232)
		return
	}

	// sharing something that doesn't exist
	_, err33 := u.ShareFile("fdfdds", "bob")
	if err33 == nil {
		t.Error("should fail", err33)
		return
	}

	initialFile, err = u.LoadFile("file1")
	if err != nil {
		t.Error("Failed to download the file from alice", err)
		return
	}

	magic_string, err = u.ShareFile("file1", "bob")
	if err != nil {
		t.Error("Failed to share the a file", err)
		return
	}

	err = u2.ReceiveFile("file2", "alice", magic_string)
	if err != nil {
		t.Error("Failed to receive the share message", err)
		return
	}

	loadedBeforeAppend, err = u2.LoadFile("file2")
	if err != nil {
		t.Error("Failed to download the file after sharing", err)
		return
	}
	if !reflect.DeepEqual(initialFile, loadedBeforeAppend) {
		t.Error("Shared file is not the same", initialFile, loadedBeforeAppend)
		return
	}
}


func TestOtherAppend(t *testing.T) {
	// And some more tests, because
	u, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}
	u2, err2 := GetUser("bob", "foobar")
	if err2 != nil {
		t.Error("Failed to initialize bob", err2)
		return
	}

	twoFile, _ := u2.LoadFile("file2")

	v := []byte("This is a test")

	if !reflect.DeepEqual(v, twoFile) {
		t.Error("Downloaded file is not the same", v, twoFile)
		return
	}

	appendGuy := []byte("I like chocolate!!!")

	newAppended := append(v, appendGuy...)

	error3 := u2.AppendFile("file2", appendGuy)
	if error3 != nil {
		t.Error("failed to append", error3)
		return
	}

	loadedNewGuy, error8 := u2.LoadFile("file2")
	if error8 != nil {
		t.Error("failed to load new guy", error8)
		return
	}
	if !reflect.DeepEqual(loadedNewGuy, newAppended) {
		t.Error("Downloaded file is not the same", loadedNewGuy, newAppended)
		return
	}

	checkAliceAppended, err23 := u.LoadFile("file1")
	if err23 != nil {
		t.Error("failed to load new guy for alice", err23)
		return
	}
	if !reflect.DeepEqual(checkAliceAppended, newAppended) {
		t.Error("Alice didn't see new guy", checkAliceAppended, newAppended)
	}

}


func TestRevoke(t *testing.T) {
	// And some more tests, because
	v := []byte("This is a testI like chocolate!!!")

	u, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}

	u2, err := GetUser("bob", "foobar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}

	_, error1 := u2.LoadFile("file2")
	if error1 != nil {
		t.Error("failed to load file2", error1)
		return
	}

	userlib.SetDebugStatus(true)

	magic_string2, err := u.ShareFile("file1", "bob")
	if err != nil {
		t.Error("Failed to share the a file", err)
		return
	}
	err = u2.ReceiveFile("file1", "alice", magic_string2)

	userlib.DebugMsg("Key 32232is %v, %v")

	error3 := u.RevokeFile("file1", "bob")

	if error3 != nil {
		t.Error("failed to revoke", error3)
		return
	}

	userlib.SetDebugStatus(false)
	//
	////revoking someon that doesn't exist
	//error4 := u.RevokeFile("file1", "dsonbsdo")
	//if error4 == nil {
	//	t.Error("failed to revoke", error4)
	//	return
	//}


	//revoking file that doesn't exist
	error5 := u.RevokeFile("ewoebowe", "bob")
	if error5 == nil {
		t.Error("failed to revoke", error5)
		return
	}


	hihihi, error4 := u.LoadFile("file1")
	if error4 != nil {
		t.Error("failed to load file2", error4)
		return
	}

	if !reflect.DeepEqual(v, hihihi) {
		t.Error("Shared file is not the same", v, hihihi)
	}



	_, error4 = u2.LoadFile("file2")
	if error4 == nil {
		t.Error("should fail to load file2", error4)
		return
	}


	err = u2.ReceiveFile("newAppendTest", "alice", magic_string2)


	appendFile := []byte("hello world")
	appendFile2 := []byte("John Moon Skillman")

	u.AppendFile("appendTest", appendFile)
	u.AppendFile("appendTest", appendFile2)

	user1FILE, err := u.LoadFile("appendTest")
	if err != nil {
		t.Error("user 1 can't get his own file", err)
		return
	}

	loadedAfterAppend, err := u2.LoadFile("newAppendTest")

	if reflect.DeepEqual(user1FILE, loadedAfterAppend) {
		t.Error("These two files should be different", user1FILE, loadedAfterAppend)
		return
	}
}

func TestRevoke2(t *testing.T) {
	// And some more tests, because
	originalGuy := []byte("This is a testI like chocolate!!!")

	u, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}

	u2, err := GetUser("bob", "foobar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}

	user3, err := GetUser("Lloyd", "Ashton")
	if err != nil {
		// t.Error says the test fails
		t.Error("Failed to initialize user", err)
		return
	}

	u.StoreFile("newFileAppend", originalGuy)

	magic_string2, err := u.ShareFile("newFileAppend", "bob")
	if err != nil {
		t.Error("Failed to share the a file", err)
		return
	}
	userlib.SetDebugStatus(true)

	err = u2.ReceiveFile("newAppendTest", "alice", magic_string2)

	originalGuytest, err3 := u.LoadFile("newFileAppend")
	if err3 != nil {
		t.Error("user 1 can't get his own file", err)
		return
	}

	if !reflect.DeepEqual(originalGuytest, originalGuy) {
		t.Error("These two files should be different", originalGuy, originalGuytest)
		return
	}

	originalGuytest2, err3 := u2.LoadFile("newAppendTest")
	if err3 != nil {
		t.Error("user 1 can't get his own file", err)
		return
	}

	if !reflect.DeepEqual(originalGuytest2, originalGuy) {
		t.Error("These two files should be different", originalGuy, originalGuytest2)
		return
	}

	magic_string3, err := u2.ShareFile("newAppendTest", "Lloyd")
	if err != nil {
		t.Error("Failed to share the a file", err)
		return
	}

	err = user3.ReceiveFile("thirdGuyLoad", "bob", magic_string3)
	userlib.SetDebugStatus(false)


	originalGuytest3333, err3 := user3.LoadFile("thirdGuyLoad")
	if err3 != nil {
		t.Error("user 1 can't get his own file", err)
		return
	}

	if !reflect.DeepEqual(originalGuytest3333, originalGuy) {
		t.Error("These two files should be the same", originalGuytest3333, originalGuy)
		return
	}


	u.RevokeFile("newFileAppend", "bob")

	file2121, wtf := u.LoadFile("appendTest")

	if wtf != nil {
		t.Error("user 1 can't get his own file", wtf)
		return
	}

	if reflect.DeepEqual(file2121, originalGuy) {
		t.Error("These two files should be different", file2121, originalGuy)
		return
	}

	newGuyAppend := []byte("pass the tests por favor")
	originalGuy = append(originalGuy, newGuyAppend...)

	error21 := u.AppendFile("newFileAppend", newGuyAppend)

	if error21 != nil {
		t.Error("u should able to append", error21)
		return
	}

	originalGuytest3, err3 := u.LoadFile("newFileAppend")
	if err3 != nil {
		t.Error("user 1 can't get his own file", err)
		return
	}

	if !reflect.DeepEqual(originalGuytest3, originalGuy) {
		t.Error("These two files should be different", originalGuytest3, originalGuy)
		return
	}

	originalGuytest4, _ := u2.LoadFile("newAppendTest")

	if reflect.DeepEqual(originalGuytest4, originalGuy) {
		t.Error("These two files should be different", originalGuytest4, originalGuy)
		return
	}

	error2321 := u2.AppendFile("newAppendTest", newGuyAppend)

	if error2321 == nil {
		t.Error("u2 should not be able to append file", error2321)
		return
	}

	originalGuytest5, err3 := u.LoadFile("newFileAppend")
	if err3 != nil {
		t.Error("user 1 can't get his own file", err)
		return
	}

	if !reflect.DeepEqual(originalGuytest5, originalGuy) {
		t.Error("These two files should be different", originalGuy, originalGuytest5)
		return
	}

	originalGuytest4334, _ := user3.LoadFile("thirdGuyLoad")

	if reflect.DeepEqual(originalGuytest4334, originalGuy) {
		t.Error("These two files should be different", originalGuytest4334, originalGuy)
		return
	}

	error23212 := user3.AppendFile("thirdGuyLoad", newGuyAppend)

	if error23212 == nil {
		t.Error("user3 should not be able to append file", error23212)
		return
	}

	magic_string5, _ := user3.ShareFile("thirdGuyLoad", "alice")

	_ = u.ReceiveFile("last guy", "Lloyd", magic_string5)
}

func TestOVERWRITEpoints(t *testing.T) {
	dictionary := userlib.DatastoreGetMap()
	u1, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to reload user", err)
		return
	}
	for counter := range dictionary {
		userlib.DatastoreSet(counter, []byte("randomeshit"))
	}
	_, err = GetUser("Alec", "Jo")
	if err == nil {
		t.Error("Failed to reload user", err)
		return
	}

	_, error := u1.LoadFile("file1")
	if err == nil {
		t.Error("should faile", error)
		return
	}
}







